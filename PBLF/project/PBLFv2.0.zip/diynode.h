#define GameCnt 5
typedef struct Node{
    char username[10];
    long long password; int taskid;
    int data[GameCnt+1][10];
}node;
