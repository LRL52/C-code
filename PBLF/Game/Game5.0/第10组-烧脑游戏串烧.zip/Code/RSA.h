#define int long long
int ksm(int, int);
int Encode(int);
int Decode(int);
#undef int
