#define GameCnt 8
typedef struct Node{
    char username[12];
    char password[35]; int taskid;
    int data[GameCnt+5][10];
}node;
